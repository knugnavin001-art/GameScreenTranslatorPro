@echo off
setlocal
cd /d "%~dp0"
echo ===============================================
echo Game Screen Translator Pro - Build APK
echo ===============================================
where java >nul 2>nul
if errorlevel 1 (
  echo ERROR: Java/JDK is not installed or is not on PATH.
  echo Install JDK 17, then try again.
  pause
  exit /b 1
)
where gradle >nul 2>nul
if errorlevel 1 (
  echo ERROR: Gradle is not installed or is not on PATH.
  echo Recommended: open this folder in Android Studio and build via its terminal,
  echo or upload the project to GitHub and run the Build Android APK workflow.
  pause
  exit /b 1
)
if not defined ANDROID_HOME if not defined ANDROID_SDK_ROOT (
  echo ERROR: ANDROID_HOME or ANDROID_SDK_ROOT is not set.
  echo Install Android SDK in Android Studio > Tools > SDK Manager.
  pause
  exit /b 1
)
gradle --no-daemon assembleDebug --stacktrace
if errorlevel 1 (
  echo.
  echo BUILD FAILED. See the errors above.
  pause
  exit /b 1
)
echo.
echo SUCCESS. APK location:
echo %CD%\app\build\outputs\apk\debug\app-debug.apk
explorer "%CD%\app\build\outputs\apk\debug"
pause
