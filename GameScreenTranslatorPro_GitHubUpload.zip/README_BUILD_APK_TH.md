# Game Screen Translator Pro — วิธีสร้าง APK

โฟลเดอร์นี้เป็นโปรเจกต์ Android สำหรับสร้าง APK โดยใช้ GitHub Actions เพราะต้องมี Android SDK, Gradle และดาวน์โหลดไลบรารีภายนอกเพื่อคอมไพล์

## วิธีสร้าง APK

### วิธีที่ง่ายที่สุด: GitHub Actions (ไม่ต้องติดตั้ง SDK ในเครื่อง)

1. แตกไฟล์ ZIP นี้ แล้วเข้าโฟลเดอร์ `AndroidGameScreenTranslator`
2. สร้าง repository ใหม่บน GitHub (แนะนำตั้งเป็น **Private** หากไม่ต้องการเผยแพร่ซอร์สโค้ด)
3. อัปโหลด **ไฟล์และโฟลเดอร์ทั้งหมดที่อยู่ภายใน** `AndroidGameScreenTranslator` ไปยังรากของ repository โดยต้องเห็น `app`, `build.gradle.kts`, `settings.gradle.kts` และ `.github` อยู่ที่ระดับบนสุด
4. เปิดแท็บ **Actions** แล้วเลือก **Build Android APK (Game Screen Translator Pro)**
5. กด **Run workflow** หาก workflow ยังไม่เริ่มทำงานเองหลังอัปโหลดไฟล์
6. รอจนงานเสร็จและแสดงสถานะสีเขียว หากล้มเหลวให้เปิดขั้นตอนที่เป็นสีแดงเพื่อดูสาเหตุ
7. เปิดงานที่สำเร็จ แล้วดาวน์โหลด artifact ชื่อ `GameScreenTranslator-Pro-APK`
8. แตก ZIP ของ artifact จะได้ `app-debug.apk` สำหรับติดตั้งบน Android

Workflow จะติดตั้ง Android SDK Platform 34 และ Build Tools ที่จำเป็นก่อนเริ่ม build

### วิธีสร้างใน Windows ที่ติดตั้งเครื่องมือครบแล้ว

1. ติดตั้ง JDK 17 และ Android SDK (API 34 / Build Tools 34.0.0)
2. ตรวจให้แน่ใจว่าคำสั่ง `gradle` ใช้ได้ใน Command Prompt และกำหนด `ANDROID_HOME` หรือ `ANDROID_SDK_ROOT` แล้ว
3. ดับเบิลคลิก `BUILD_APK_WINDOWS.bat` หรือรันจาก Command Prompt
4. APK จะอยู่ที่ `app\build\outputs\apk\debug\app-debug.apk`

## หมายเหตุ

- APK ที่ workflow สร้างเป็น **debug APK ที่ลงลายเซ็น debug แล้ว** เหมาะสำหรับติดตั้งทดสอบ ไม่ใช่ไฟล์ release สำหรับเผยแพร่บน Play Store
- แอปต้องขอสิทธิ์แสดงทับแอปอื่นและบันทึกหน้าจอ และต้องเชื่อมต่ออินเทอร์เน็ตตอนดาวน์โหลดโมเดลแปลภาษาในครั้งแรก
- เวอร์ชันนี้ยังไม่ได้ยืนยันผลคอมไพล์จริงในสภาพแวดล้อมปัจจุบัน เพราะสภาพแวดล้อมที่จัดทำไฟล์นี้ไม่มี Android SDK/Gradle และไม่สามารถดาวน์โหลดเครื่องมือ build จากเครือข่ายได้
