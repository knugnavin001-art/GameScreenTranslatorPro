package com.example.screentranslator

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var spinnerSourceLang: Spinner
    private lateinit var tvStatus: TextView
    private lateinit var btnStartTranslate: Button

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (Settings.canDrawOverlays(this)) {
            requestScreenCapturePermission()
        } else {
            Toast.makeText(this, "กรุณาอนุญาตสิทธิ์แสดงผลทับแอปอื่นก่อนใช้งาน", Toast.LENGTH_LONG).show()
        }
    }

    private val mediaProjectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val selectedLang = SourceLang.entries[spinnerSourceLang.selectedItemPosition]
            val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, result.data)
                putExtra(ScreenCaptureService.EXTRA_SOURCE_LANG, selectedLang.ordinal)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
            moveTaskToBack(true)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        spinnerSourceLang = findViewById(R.id.spinnerSourceLang)
        tvStatus = findViewById(R.id.tvStatus)
        btnStartTranslate = findViewById(R.id.btnStartTranslate)

        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            SourceLang.entries.map { it.displayName }
        )
        spinnerSourceLang.adapter = adapter
        spinnerSourceLang.setSelection(SourceLang.ENGLISH.ordinal)

        btnStartTranslate.setOnClickListener {
            val selectedLang = SourceLang.entries[spinnerSourceLang.selectedItemPosition]
            downloadModelAndStart(selectedLang)
        }
    }

    private fun downloadModelAndStart(lang: SourceLang) {
        btnStartTranslate.isEnabled = false
        tvStatus.text = "กำลังเตรียมชุดข้อมูลแปลภาษา ${lang.displayName} -> ไทย (ใช้เวลาเฉพาะครั้งแรก)..."

        lifecycleScope.launch {
            val tempManager = TranslationManager(lang)
            val ready = tempManager.prepareModel()
            tempManager.close()
            btnStartTranslate.isEnabled = true

            if (ready) {
                tvStatus.text = "สถานะ: โมเดลพร้อมใช้งาน กำลังขอสิทธิ์หน้าจอ..."
                checkOverlayAndStart()
            } else {
                tvStatus.text = "สถานะ: ดาวน์โหลดโมเดลไม่สำเร็จ กรุณาตรวจสอบอินเทอร์เน็ต"
            }
        }
    }

    private fun checkOverlayAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlayPermissionLauncher.launch(intent)
        } else {
            requestScreenCapturePermission()
        }
    }

    private fun requestScreenCapturePermission() {
        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjectionLauncher.launch(projectionManager.createScreenCaptureIntent())
    }
}
