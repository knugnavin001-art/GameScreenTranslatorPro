package com.example.screentranslator

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.View

class OverlayView(context: Context) : View(context) {

    private var translatedBlocks: List<TranslatedBlock> = emptyList()
    private var activeRoiRect: Rect? = null

    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(110, 0, 229, 255)
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
    }

    private val roiGuidePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(150, 0, 255, 163)
        style = Paint.Style.STROKE
        strokeWidth = 3f
        pathEffect = DashPathEffect(floatArrayOf(16f, 12f), 0f)
    }

    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 36f
    }

    fun updateBlocks(blocks: List<TranslatedBlock>) {
        translatedBlocks = blocks
        postInvalidate()
    }

    fun setRoiIndicator(rect: Rect?) {
        activeRoiRect = rect
        postInvalidate()
    }

    fun clearBlocks() {
        translatedBlocks = emptyList()
        postInvalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        activeRoiRect?.let { roi ->
            canvas.drawRoundRect(RectF(roi), 12f, 12f, roiGuidePaint)
        }

        for (block in translatedBlocks) {
            val rect = RectF(block.boundingBox)
            rect.inset(-6f, -6f)

            boxPaint.color = block.backgroundColor
            canvas.drawRoundRect(rect, 8f, 8f, boxPaint)
            canvas.drawRoundRect(rect, 8f, 8f, borderPaint)

            textPaint.color = block.textColor
            val boxWidth = rect.width().toInt().coerceAtLeast(40)
            val boxHeight = rect.height().toInt().coerceAtLeast(24)

            var fittedTextSize = 38f
            var staticLayout: StaticLayout

            while (true) {
                textPaint.textSize = fittedTextSize
                staticLayout = StaticLayout.Builder
                    .obtain(block.translatedText, 0, block.translatedText.length, textPaint, boxWidth)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .setLineSpacing(0f, 1.0f)
                    .setIncludePad(false)
                    .build()

                if (staticLayout.height <= boxHeight || fittedTextSize <= 16f) {
                    break
                }
                fittedTextSize -= 2f
            }

            canvas.save()
            val offsetY = rect.top + ((boxHeight - staticLayout.height) / 2f).coerceAtLeast(0f)
            canvas.translate(rect.left + 4f, offsetY)
            staticLayout.draw(canvas)
            canvas.restore()
        }
    }
}
