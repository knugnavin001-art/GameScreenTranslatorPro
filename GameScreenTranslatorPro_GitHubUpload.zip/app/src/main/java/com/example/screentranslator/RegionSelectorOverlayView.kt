package com.example.screentranslator

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class RegionSelectorOverlayView(
    context: Context,
    private val onRegionSelected: (Rect?) -> Unit
) : View(context) {

    private var startX = 0f
    private var startY = 0f
    private var currentX = 0f
    private var currentY = 0f
    private var isDragging = false

    private val dimPaint = Paint().apply {
        color = Color.argb(130, 0, 0, 0)
        style = Paint.Style.FILL
    }

    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(60, 0, 255, 163)
        style = Paint.Style.FILL
    }

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(0, 255, 163)
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }

    private val guideTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 42f
        textAlign = Paint.Align.CENTER
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dimPaint)

        canvas.drawText(
            "ใช้นิ้วลากกรอบคลุม 'กล่องบทสนทนาเกม' (หรือแตะ 1 ครั้งเพื่อแปลเต็มจอ)",
            width / 2f,
            height / 5f,
            guideTextPaint
        )

        if (isDragging) {
            val left = min(startX, currentX)
            val top = min(startY, currentY)
            val right = max(startX, currentX)
            val bottom = max(startY, currentY)
            canvas.drawRect(left, top, right, bottom, boxPaint)
            canvas.drawRect(left, top, right, bottom, strokePaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                startX = event.x
                startY = event.y
                currentX = event.x
                currentY = event.y
                isDragging = true
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                currentX = event.x
                currentY = event.y
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP -> {
                isDragging = false
                val dx = abs(currentX - startX)
                val dy = abs(currentY - startY)
                if (dx > 60 && dy > 40) {
                    val selected = Rect(
                        min(startX, currentX).toInt(),
                        min(startY, currentY).toInt(),
                        max(startX, currentX).toInt(),
                        max(startY, currentY).toInt()
                    )
                    onRegionSelected(selected)
                } else {
                    onRegionSelected(null)
                }
                return true
            }
        }
        return super.onTouchEvent(event)
    }
}
