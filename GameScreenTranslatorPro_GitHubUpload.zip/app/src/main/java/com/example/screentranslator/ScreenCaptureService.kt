package com.example.screentranslator

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

class ScreenCaptureService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "EXTRA_RESULT_CODE"
        const val EXTRA_RESULT_DATA = "EXTRA_RESULT_DATA"
        const val EXTRA_SOURCE_LANG = "EXTRA_SOURCE_LANG"
        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "screen_translator_pro_channel"
    }

    private lateinit var windowManager: WindowManager
    private lateinit var overlayView: OverlayView
    private lateinit var floatingControlLayout: LinearLayout
    private lateinit var translationManager: TranslationManager
    private var regionSelectorView: RegionSelectorOverlayView? = null

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var realtimeLoopJob: Job? = null

    private var isAutoMode = true
    private var isPaused = false
    private var roiRect: Rect? = null
    private var previousBorderSignature: IntArray? = null

    private var screenWidth = 0
    private var screenHeight = 0
    private var screenDensity = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIFICATION_ID, createNotification())
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        updateScreenMetrics()
        setupOverlayView()
        setupFloatingControl()
    }

    private fun updateScreenMetrics() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        screenDensity = metrics.densityDpi
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val oldW = screenWidth
        val oldH = screenHeight
        updateScreenMetrics()

        if (oldW != screenWidth || oldH != screenHeight) {
            previousBorderSignature = null
            overlayView.clearBlocks()
            rebuildVirtualDisplay()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED
        val resultData: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }
        val langOrdinal = intent?.getIntExtra(EXTRA_SOURCE_LANG, SourceLang.ENGLISH.ordinal)
            ?: SourceLang.ENGLISH.ordinal
        val selectedLang = SourceLang.entries[langOrdinal]

        translationManager = TranslationManager(selectedLang)

        if (resultCode == Activity.RESULT_OK && resultData != null) {
            startMediaProjection(resultCode, resultData)
            startRealtimeTranslationLoop()
        } else {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun setupOverlayView() {
        overlayView = OverlayView(this)
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        windowManager.addView(overlayView, params)
    }

    private fun setupFloatingControl() {
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 140
        }

        floatingControlLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.argb(215, 22, 27, 34))
            setPadding(12, 8, 12, 8)
        }

        val modeBtn = Button(this).apply {
            text = "โหมด: Auto"
            textSize = 11f
        }

        val tapTranslateBtn = Button(this).apply {
            text = "🔍 แปล"
            textSize = 11f
            visibility = View.GONE
            setOnClickListener {
                serviceScope.launch {
                    previousBorderSignature = null
                    captureAndTranslateOnce()
                }
            }
        }

        modeBtn.setOnClickListener {
            isAutoMode = !isAutoMode
            previousBorderSignature = null
            if (isAutoMode) {
                modeBtn.text = "โหมด: Auto"
                tapTranslateBtn.visibility = View.GONE
                Toast.makeText(this, "เปลี่ยนเป็นโหมดแปลอัตโนมัติ (Auto)", Toast.LENGTH_SHORT).show()
            } else {
                modeBtn.text = "โหมด: Tap"
                tapTranslateBtn.visibility = View.VISIBLE
                Toast.makeText(this, "เปลี่ยนเป็นโหมดแตะเพื่อแปล (ประหยัดแบต)", Toast.LENGTH_SHORT).show()
            }
        }

        val roiBtn = Button(this).apply {
            text = "กรอบโซน"
            textSize = 11f
            setOnClickListener {
                openRegionSelector(this)
            }
        }

        val pauseBtn = Button(this).apply {
            text = "พัก"
            textSize = 11f
            setOnClickListener {
                isPaused = !isPaused
                if (isPaused) {
                    text = "เริ่มต่อ"
                    overlayView.clearBlocks()
                } else {
                    text = "พัก"
                    previousBorderSignature = null
                }
            }
        }

        val closeBtn = Button(this).apply {
            text = "✕"
            textSize = 11f
            setOnClickListener { stopSelf() }
        }

        floatingControlLayout.addView(modeBtn)
        floatingControlLayout.addView(tapTranslateBtn)
        floatingControlLayout.addView(roiBtn)
        floatingControlLayout.addView(pauseBtn)
        floatingControlLayout.addView(closeBtn)

        floatingControlLayout.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = initialX + (event.rawX - initialTouchX).toInt()
                        params.y = initialY + (event.rawY - initialTouchY).toInt()
                        windowManager.updateViewLayout(floatingControlLayout, params)
                        return true
                    }
                }
                return false
            }
        })

        windowManager.addView(floatingControlLayout, params)
    }

    private fun openRegionSelector(roiBtn: Button) {
        if (regionSelectorView != null) return

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )

        regionSelectorView = RegionSelectorOverlayView(this) { selectedRect ->
            roiRect = selectedRect
            overlayView.setRoiIndicator(selectedRect)
            overlayView.clearBlocks()
            previousBorderSignature = null

            roiBtn.text = if (selectedRect != null) "โซน: ล็อก" else "กรอบโซน"
            regionSelectorView?.let { windowManager.removeView(it) }
            regionSelectorView = null
        }

        windowManager.addView(regionSelectorView, params)
    }

    private fun startMediaProjection(resultCode: Int, resultData: Intent) {
        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = projectionManager.getMediaProjection(resultCode, resultData)
        rebuildVirtualDisplay()
    }

    private fun rebuildVirtualDisplay() {
        virtualDisplay?.release()
        imageReader?.close()

        if (mediaProjection == null || screenWidth <= 0 || screenHeight <= 0) return

        imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "GameScreenCapturePro",
            screenWidth,
            screenHeight,
            screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            null
        )
    }

    private fun startRealtimeTranslationLoop() {
        realtimeLoopJob = serviceScope.launch {
            translationManager.prepareModel()

            while (isActive) {
                if (!isPaused && isAutoMode) {
                    val probeBitmap = captureCurrentFrame()
                    if (probeBitmap != null) {
                        val currentSig = extractBorderSignature(probeBitmap, roiRect)
                        val sceneChanged = hasSceneChanged(previousBorderSignature, currentSig)
                        probeBitmap.recycle()

                        if (sceneChanged) {
                            captureAndTranslateOnce()
                        }
                    }
                }
                delay(950)
            }
        }
    }

    private suspend fun captureAndTranslateOnce() {
        overlayView.visibility = View.INVISIBLE
        delay(55)

        val cleanBitmap = captureCurrentFrame()
        overlayView.visibility = View.VISIBLE

        if (cleanBitmap != null) {
            previousBorderSignature = extractBorderSignature(cleanBitmap, roiRect)
            val blocks = withContext(Dispatchers.Default) {
                translationManager.processScreenBitmap(cleanBitmap, roiRect)
            }
            cleanBitmap.recycle()
            if (!isPaused) {
                overlayView.updateBlocks(blocks)
            }
        }
    }

    private fun extractBorderSignature(bitmap: Bitmap, roi: Rect?): IntArray {
        val target = roi ?: Rect(
            (bitmap.width * 0.05f).toInt(),
            (bitmap.height * 0.05f).toInt(),
            (bitmap.width * 0.95f).toInt(),
            (bitmap.height * 0.95f).toInt()
        )
        val sig = IntArray(24)
        var idx = 0
        for (i in 0 until 12) {
            val x = (target.left + (target.width() * i) / 11).coerceIn(0, bitmap.width - 1)
            val topY = target.top.coerceIn(0, bitmap.height - 1)
            val botY = target.bottom.coerceIn(0, bitmap.height - 1)
            sig[idx++] = bitmap.getPixel(x, topY)
            sig[idx++] = bitmap.getPixel(x, botY)
        }
        return sig
    }

    private fun hasSceneChanged(oldSig: IntArray?, newSig: IntArray): Boolean {
        if (oldSig == null || oldSig.size != newSig.size) return true
        var diffSum = 0
        for (i in oldSig.indices) {
            val c1 = oldSig[i]
            val c2 = newSig[i]
            diffSum += abs(Color.red(c1) - Color.red(c2)) +
                    abs(Color.green(c1) - Color.green(c2)) +
                    abs(Color.blue(c1) - Color.blue(c2))
        }
        val avgDiffPerPoint = diffSum / oldSig.size
        return avgDiffPerPoint > 18
    }

    private fun captureCurrentFrame(): Bitmap? {
        val image = imageReader?.acquireLatestImage() ?: return null
        return try {
            val planes = image.planes
            val buffer = planes[0].buffer
            val pixelStride = planes[0].pixelStride
            val rowStride = planes[0].rowStride
            val rowPadding = rowStride - pixelStride * screenWidth

            val fullBitmap = Bitmap.createBitmap(
                screenWidth + rowPadding / pixelStride,
                screenHeight,
                Bitmap.Config.ARGB_8888
            )
            fullBitmap.copyPixelsFromBuffer(buffer)
            val cropped = Bitmap.createBitmap(fullBitmap, 0, 0, screenWidth, screenHeight)
            fullBitmap.recycle()
            cropped
        } catch (e: Exception) {
            null
        } finally {
            image.close()
        }
    }

    private fun createNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Real-time Game Screen Translator Pro",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Game Translator Pro กำลังทำงาน")
            .setContentText("สลับโหมด Auto/Tap หรือลากกรอบโซนแปลได้จากปุ่มลอย")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .build()
    }

    override fun onDestroy() {
        realtimeLoopJob?.cancel()
        serviceScope.cancel()
        regionSelectorView?.let { windowManager.removeView(it) }
        if (::overlayView.isInitialized) windowManager.removeView(overlayView)
        if (::floatingControlLayout.isInitialized) windowManager.removeView(floatingControlLayout)
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
        if (::translationManager.isInitialized) translationManager.close()
        super.onDestroy()
    }
}
