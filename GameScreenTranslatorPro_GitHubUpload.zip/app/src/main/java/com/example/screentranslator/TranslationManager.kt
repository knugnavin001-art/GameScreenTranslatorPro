package com.example.screentranslator

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.util.LruCache
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await
import kotlin.math.max
import kotlin.math.min

data class TranslatedBlock(
    val originalText: String,
    val translatedText: String,
    val boundingBox: Rect,
    val backgroundColor: Int,
    val textColor: Int
)

enum class SourceLang(val displayName: String, val mlKitLangCode: String) {
    ENGLISH("English (อังกฤษ)", TranslateLanguage.ENGLISH),
    JAPANESE("Japanese (ญี่ปุ่น)", TranslateLanguage.JAPANESE),
    CHINESE("Chinese (จีน)", TranslateLanguage.CHINESE),
    KOREAN("Korean (เกาหลี)", TranslateLanguage.KOREAN)
}

class TranslationManager(private var sourceLang: SourceLang = SourceLang.ENGLISH) {

    private var recognizer: TextRecognizer = createRecognizer(sourceLang)
    private var translator: Translator = createTranslator(sourceLang.mlKitLangCode)
    private val translationCache = LruCache<String, String>(500)

    private fun createRecognizer(lang: SourceLang): TextRecognizer {
        return when (lang) {
            SourceLang.ENGLISH -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            SourceLang.JAPANESE -> TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
            SourceLang.CHINESE -> TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
            SourceLang.KOREAN -> TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        }
    }

    private fun createTranslator(sourceLangCode: String): Translator {
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(sourceLangCode)
            .setTargetLanguage(TranslateLanguage.THAI)
            .build()
        return Translation.getClient(options)
    }

    suspend fun prepareModel(): Boolean {
        val conditions = DownloadConditions.Builder().build()
        return try {
            translator.downloadModelIfNeeded(conditions).await()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun processScreenBitmap(fullBitmap: Bitmap, roiRect: Rect?): List<TranslatedBlock> {
        val safeRoi = roiRect?.let {
            val left = it.left.coerceIn(0, fullBitmap.width - 1)
            val top = it.top.coerceIn(0, fullBitmap.height - 1)
            val right = it.right.coerceIn(left + 1, fullBitmap.width)
            val bottom = it.bottom.coerceIn(top + 1, fullBitmap.height)
            if (right - left > 20 && bottom - top > 20) Rect(left, top, right, bottom) else null
        }

        val targetBitmap = if (safeRoi != null) {
            Bitmap.createBitmap(fullBitmap, safeRoi.left, safeRoi.top, safeRoi.width(), safeRoi.height())
        } else {
            fullBitmap
        }

        val inputImage = InputImage.fromBitmap(targetBitmap, 0)
        val visionText = recognizer.process(inputImage).await()
        val results = mutableListOf<TranslatedBlock>()

        for (block in visionText.textBlocks) {
            val localBox = block.boundingBox ?: continue
            val rawText = block.text.replace("\n", " ").trim()

            if (rawText.length < 2 || rawText.none { it.isLetter() }) continue

            val translated = translationCache.get(rawText) ?: try {
                val res = translator.translate(rawText).await()
                translationCache.put(rawText, res)
                res
            } catch (e: Exception) {
                rawText
            }

            val screenBox = if (safeRoi != null) {
                Rect(
                    localBox.left + safeRoi.left,
                    localBox.top + safeRoi.top,
                    localBox.right + safeRoi.left,
                    localBox.bottom + safeRoi.top
                )
            } else {
                localBox
            }

            val sampledBg = sampleBackgroundColor(fullBitmap, screenBox)
            val textColor = getContrastTextColor(sampledBg)

            results.add(
                TranslatedBlock(
                    originalText = rawText,
                    translatedText = translated,
                    boundingBox = screenBox,
                    backgroundColor = sampledBg,
                    textColor = textColor
                )
            )
        }

        if (safeRoi != null && targetBitmap !== fullBitmap) {
            targetBitmap.recycle()
        }
        return results
    }

    private fun sampleBackgroundColor(bitmap: Bitmap, box: Rect): Int {
        val samplePoints = mutableListOf<Int>()
        val left = max(0, box.left - 4)
        val right = min(bitmap.width - 1, box.right + 4)
        val top = max(0, box.top - 4)
        val bottom = min(bitmap.height - 1, box.bottom + 4)
        val midX = (left + right) / 2
        val midY = (top + bottom) / 2

        samplePoints.add(bitmap.getPixel(left, top))
        samplePoints.add(bitmap.getPixel(right, top))
        samplePoints.add(bitmap.getPixel(left, bottom))
        samplePoints.add(bitmap.getPixel(right, bottom))
        samplePoints.add(bitmap.getPixel(midX, top))
        samplePoints.add(bitmap.getPixel(midX, bottom))
        samplePoints.add(bitmap.getPixel(left, midY))
        samplePoints.add(bitmap.getPixel(right, midY))

        var rSum = 0
        var gSum = 0
        var bSum = 0
        for (pixel in samplePoints) {
            rSum += Color.red(pixel)
            gSum += Color.green(pixel)
            bSum += Color.blue(pixel)
        }
        val count = samplePoints.size
        return Color.argb(235, rSum / count, gSum / count, bSum / count)
    }

    private fun getContrastTextColor(bgColor: Int): Int {
        val r = Color.red(bgColor) / 255.0
        val g = Color.green(bgColor) / 255.0
        val b = Color.blue(bgColor) / 255.0
        val luminance = 0.299 * r + 0.587 * g + 0.114 * b
        return if (luminance > 0.58) Color.rgb(20, 20, 20) else Color.WHITE
    }

    fun close() {
        recognizer.close()
        translator.close()
    }
}
